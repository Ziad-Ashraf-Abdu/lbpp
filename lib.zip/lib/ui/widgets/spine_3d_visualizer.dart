import 'package:flutter/material.dart';
import 'dart:math';
import '../../models/biomechanical_data.dart';
import '../../services/biomechanical_analyzer.dart';

/// 3D visualization of human spine with IMU data overlay
class Spine3DVisualizer extends StatefulWidget {
  final SpineKinematics? kinematics;
  final double width;
  final double height;

  const Spine3DVisualizer({
    Key? key,
    this.kinematics,
    this.width = 300,
    this.height = 400,
  }) : super(key: key);

  @override
  State<Spine3DVisualizer> createState() => _Spine3DVisualizerState();
}

class _Spine3DVisualizerState extends State<Spine3DVisualizer> {

  @override
  Widget build(BuildContext context) {
    return Container(
      width: widget.width,
      height: widget.height,
      decoration: BoxDecoration(
        color: Colors.grey[900],
        borderRadius: BorderRadius.circular(16),
      ),
      child: Stack(
        children: [
          // Background visualization
          CustomPaint(
            painter: _SpinePainter(
              kinematics: widget.kinematics,
            ),
            size: Size(widget.width, widget.height),
          ),

          // Data overlay
          if (widget.kinematics != null)
            Positioned(
              bottom: 20,
              left: 0,
              right: 0,
              child: _buildDataOverlay(widget.kinematics!),
            )
          else
            Center(
              child: Text(
                'Waiting for IMU data...',
                style: TextStyle(color: Colors.white70),
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildDataOverlay(SpineKinematics kinematics) {
    final analyzer = BiomechanicalAnalyzer();
    final analysis = analyzer.checkThresholds(kinematics);

    return Container(
      margin: EdgeInsets.all(10),
      padding: EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.black.withOpacity(0.7),
        borderRadius: BorderRadius.circular(8),
      ),
      child: Column(
        children: [
          // IMU status
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              _buildSensorDot('T12/L1', Colors.blue),
              SizedBox(width: 20),
              _buildSensorDot('L4/L5', Colors.green),
            ],
          ),
          SizedBox(height: 10),

          // Motion indicators
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              _buildMotionIndicator('Flexion', kinematics.relativeFlexion, 60.0),
              _buildMotionIndicator('Ext', kinematics.relativeExtension, 30.0),
              _buildMotionIndicator('Bend', kinematics.relativeLateralBend, 30.0),
              _buildMotionIndicator('Rot', kinematics.relativeRotation, 30.0), // ADD THIS LINE
              _buildMotionIndicator('Comp', kinematics.estimatedCompression, 100.0),
            ],
          ),

          // Safety status
          SizedBox(height: 8),
          Container(
            padding: EdgeInsets.symmetric(horizontal: 8, vertical: 4),
            decoration: BoxDecoration(
              color: analysis['isSafe'] ? Colors.green.withOpacity(0.2) : Colors.red.withOpacity(0.2),
              borderRadius: BorderRadius.circular(4),
              border: Border.all(
                color: analysis['isSafe'] ? Colors.green : Colors.red,
                width: 1,
              ),
            ),
            child: Text(
              analysis['isSafe'] ? '✓ SAFE' : '⚠ CHECK POSTURE',
              style: TextStyle(
                color: analysis['isSafe'] ? Colors.green : Colors.red,
                fontSize: 10,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSensorDot(String label, Color color) {
    return Column(
      children: [
        Container(
          width: 12,
          height: 12,
          decoration: BoxDecoration(
            color: color,
            shape: BoxShape.circle,
          ),
        ),
        SizedBox(height: 4),
        Text(
          label,
          style: TextStyle(color: color, fontSize: 10),
        ),
      ],
    );
  }

  Widget _buildMotionIndicator(String label, double value, double max) {
    final percentage = (value / max).clamp(0.0, 1.0);
    Color color;
    if (percentage < 0.7) {
      color = Colors.green;
    } else if (percentage < 0.85) {
      color = Colors.orange;
    } else {
      color = Colors.red;
    }

    return Column(
      children: [
        Text(
          '${value.toStringAsFixed(0)}',
          style: TextStyle(
            color: color,
            fontSize: 12,
            fontWeight: FontWeight.bold,
          ),
        ),
        SizedBox(height: 2),
        Text(
          label,
          style: TextStyle(color: Colors.white70, fontSize: 9),
        ),
      ],
    );
  }
}

/// Custom painter for spine visualization
class _SpinePainter extends CustomPainter {
  final SpineKinematics? kinematics;

  _SpinePainter({this.kinematics});

  @override
  void paint(Canvas canvas, Size size) {
    final centerX = size.width / 2;
    final baseY = size.height * 0.7;

    final spinePaint = Paint()
      ..color = Colors.white
      ..strokeWidth = 4
      ..style = PaintingStyle.stroke;

    // Calculate curvature based on kinematics
    double curvature = 0;
    double lateralCurve = 0;

    if (kinematics != null) {
      // Flexion/extension affects vertical curve
      curvature = (kinematics!.relativeFlexion - kinematics!.relativeExtension) / 15;
      // Lateral bending affects horizontal curve
      lateralCurve = kinematics!.relativeLateralBend / 10;
    }

    // Draw spine curve
    final path = Path();
    path.moveTo(centerX + lateralCurve * 40, 50);

    // Create smooth curve based on kinematics
    for (int i = 1; i <= 4; i++) {
      final y = 50 + (i * (size.height * 0.5 / 4));
      final curveFactor = (4 - i) / 4; // More curve at top, less at bottom
      final x = centerX + (curvature * 40 * curveFactor) + (lateralCurve * 40 * curveFactor);

      if (i == 1) {
        path.lineTo(x, y);
      } else {
        // Bezier curve for smoother transitions
        final prevY = 50 + ((i - 1) * (size.height * 0.5 / 4));
        final prevX = centerX + (curvature * 40 * ((4 - (i - 1)) / 4)) + (lateralCurve * 40 * ((4 - (i - 1)) / 4));

        final controlX1 = prevX + (x - prevX) * 0.3;
        final controlY1 = prevY + (y - prevY) * 0.3;
        final controlX2 = prevX + (x - prevX) * 0.7;
        final controlY2 = prevY + (y - prevY) * 0.7;

        path.cubicTo(controlX1, controlY1, controlX2, controlY2, x, y);
      }
    }

    canvas.drawPath(path, spinePaint);

    // Draw vertebrae as circles along the path
    final vertebraPaint = Paint()
      ..color = Colors.white
      ..style = PaintingStyle.fill;

    for (int i = 0; i < 5; i++) {
      final y = 50 + (i * (size.height * 0.5 / 4));
      final curveFactor = (4 - i) / 4;
      final x = centerX + (curvature * 40 * curveFactor) + (lateralCurve * 40 * curveFactor);

      // Vertebra circle
      canvas.drawCircle(Offset(x, y), 6, vertebraPaint);

      // ✅ ADD ROTATION VISUALIZATION HERE
      if (kinematics != null && kinematics!.relativeRotation.abs() > 0.5) {
        final rotation = kinematics!.relativeRotation;
        final rotationPaint = Paint()
          ..color = rotation > 0 ? Colors.red : Colors.blue
          ..strokeWidth = 2
          ..style = PaintingStyle.stroke;

        // Draw rotation indicator (small arc on the vertebra)
        if (rotation > 0) {
          // Right rotation - clockwise arc
          canvas.drawArc(
            Rect.fromCircle(center: Offset(x, y), radius: 8),
            0, // Starting angle
            rotation.abs() * 0.1 * pi / 180, // Arc length based on rotation (converted to radians)
            false,
            rotationPaint,
          );
        } else {
          // Left rotation - counterclockwise arc
          canvas.drawArc(
            Rect.fromCircle(center: Offset(x, y), radius: 8),
            pi, // Starting angle (opposite side)
            rotation.abs() * 0.1 * pi / 180,
            false,
            rotationPaint,
          );
        }
      }

      // Spinous process (little line behind each vertebra)
      canvas.drawLine(
        Offset(x, y),
        Offset(x + 10 - (curvature.abs() * 2), y - 8),
        Paint()
          ..color = Colors.white
          ..strokeWidth = 2
          ..style = PaintingStyle.stroke,
      );
    }



    // Draw IMU sensor positions
    final upperY = 50 + (1 * (size.height * 0.5 / 4)); // T12/L1
    final upperX = centerX + (curvature * 40 * 0.75) + (lateralCurve * 40 * 0.75);

    final lowerY = 50 + (3 * (size.height * 0.5 / 4)); // L4/L5
    final lowerX = centerX + (curvature * 40 * 0.25) + (lateralCurve * 40 * 0.25);

    // Draw sensors with pulsing effect
    final now = DateTime.now().millisecondsSinceEpoch;
    final pulse = (now % 1000) / 1000;
    final pulseRadius = 8 + (4 * sin(pulse * 3.14159 * 2));

    // Upper sensor (T12/L1) - Blue
    canvas.drawCircle(
      Offset(upperX, upperY),
      pulseRadius.toDouble(),
      Paint()
        ..color = Colors.blue.withOpacity(0.8)
        ..style = PaintingStyle.fill,
    );

    // Lower sensor (L4/L5) - Green
    canvas.drawCircle(
      Offset(lowerX, lowerY),
      8,
      Paint()
        ..color = Colors.green
        ..style = PaintingStyle.fill,
    );

    // Draw connection lines from sensors to spine
    canvas.drawLine(
      Offset(upperX, upperY),
      Offset(upperX, upperY + 15),
      Paint()
        ..color = Colors.blue.withOpacity(0.5)
        ..strokeWidth = 2
        ..style = PaintingStyle.stroke,
    );

    canvas.drawLine(
      Offset(lowerX, lowerY),
      Offset(lowerX, lowerY + 15),
      Paint()
        ..color = Colors.green.withOpacity(0.5)
        ..strokeWidth = 2
        ..style = PaintingStyle.stroke,
    );

    // Draw pelvis
    final pelvisPaint = Paint()
      ..color = Colors.grey[400]!
      ..style = PaintingStyle.fill;

    canvas.drawRect(
      Rect.fromCenter(
        center: Offset(centerX, baseY + 30),
        width: 80,
        height: 25,
      ),
      pelvisPaint,
    );
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => true;
}